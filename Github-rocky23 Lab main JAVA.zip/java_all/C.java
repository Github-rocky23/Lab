package cse.sem4.csec;
public class C
{
	public void msg2()
	{
		System.out.println("class C");
	}
}