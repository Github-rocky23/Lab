package svec;
import csed.*;
public class PackEx1
{
	public static void main(String args[])
	{
		A a=new A();
		B b=new B();
		a.msg1();
		b.msg2();
	}
}