package csed;
public class B
{
	public void msg2()
	{
		System.out.println("class B");
	}
}