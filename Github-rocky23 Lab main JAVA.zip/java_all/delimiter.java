class delimiter
{
	public static void main(String args[])
	{
		//String s[]={"25","6","2018"};
		//System.out.println("string after joining"+ " " +String.join("/",s));

		String s[]={"12","10","2010"};
		System.out.println("string after joining"+ " " +String.join(":",s));
	}
}