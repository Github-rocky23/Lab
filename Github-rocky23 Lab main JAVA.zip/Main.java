package svec;
//import csed.*;	//import cesd.A;	//import csed.B;
class Main
{
	public static void main(String args[])
	{
		new csed. A().msg1();		//A a = new A();
		new csed.B().msg2();		//B b = new B();
	}
}



//compile - > javac -d . [path] file_name
//Run - > java [c:path]/file_name.java

//// compile - > javac -d . Main.java