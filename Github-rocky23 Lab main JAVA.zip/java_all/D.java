package cse.sem4.dsec;
public class D
{
	public void msg1()
	{
		System.out.println("class D");
	}
}