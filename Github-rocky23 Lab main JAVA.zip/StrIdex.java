import java.util.Scanner ;
class StrIdex
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string : ");
        String s = sc.next();
        System.out.println(s.charAt(4));

    }
}