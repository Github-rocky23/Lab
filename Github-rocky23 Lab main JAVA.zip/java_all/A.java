package csed;
public class A
{
	public void msg1()
	{
		System.out.println("class A");
	}
}