import javax.swing.*;
class SwingExample1
{
	public static void main(String args[])
	{
		JFrame f=new JFrame();
		JButton b=new JButton();
		f.setSize(400,500);	//width and height
		f.setVisible(true);	//default=false
	}
}
		