import java.util.*;
class String5
{
	public static void main(String args[])
	{
		Scanner sc =new Scanner(System.in);
		System.out.print("Enter a string : ");
		String s=sc.next();
		System.out.println("substring from 0th position to last is : "+s.substring(0));
	}
}