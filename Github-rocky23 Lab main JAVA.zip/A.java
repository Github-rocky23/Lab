package csed;
public class A
{
	public  void msg1()
	{
		System.out.println("Class A");
	}
}

// compile - > javac -d . A.java