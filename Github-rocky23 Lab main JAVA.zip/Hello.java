package xyz;
class Hello
{
	public static void main(String args[])
	{
		System.out.println("Hello World");
	}
}

//// compile - > javac -d . Hello.java