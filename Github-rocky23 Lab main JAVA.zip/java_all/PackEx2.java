package college.engg.svec;
import cse.sem4.dsec.D;
import cse.sem4.csec.C;
public class PackEx2
{
	public static void main(String args[])
	{
		new D().msg1();
		new C().msg2();
	}
}